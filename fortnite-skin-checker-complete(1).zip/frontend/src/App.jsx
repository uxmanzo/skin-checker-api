import React, { useState } from "react";
import axios from "axios";
import "./App.css";
import skinLogoMap from "./skin_logos.json";

function App() {
  const [token, setToken] = useState("");
  const [cosmetics, setCosmetics] = useState([]);
  const [loading, setLoading] = useState(false);

  const fetchCosmetics = async () => {
    setLoading(true);
    try {
      const res = await axios.get("http://localhost:8000/api/my-cosmetics", {
        params: { token },
      });
      setCosmetics(res.data.outfits || []);
    } catch (err) {
      alert("Failed to fetch cosmetics.");
    }
    setLoading(false);
  };

  return (
    <div className="App">
      <h1>Fortnite Skin Checker</h1>
      <input
        type="text"
        value={token}
        onChange={(e) => setToken(e.target.value)}
        placeholder="Paste your Epic session token"
        style={{ width: "400px", padding: "10px", marginBottom: "10px" }}
      />
      <br />
      <button onClick={fetchCosmetics} disabled={!token || loading}>
        {loading ? "Loading..." : "Check My Skins"}
      </button>

      <div className="grid">
        {cosmetics.map((item) => {
          const logo = skinLogoMap[item.name];
          const rarity = item.rarity?.value?.toLowerCase() || "common";

          return (
            <div className={`card ${rarity}`} key={item.id}>
              <img src={item.images.icon} alt={item.name} className="skin-img" />
              <p className="skin-name">{item.name}</p>

              {item.series && (
                <span className="series-tag">{item.series.name}</span>
              )}
              {item.rarity && (
                <span className="rarity-tag">{item.rarity.displayValue}</span>
              )}
              {logo && (
                <img
                  className="custom-logo"
                  src={`/logos/${logo}`}
                  alt="logo"
                />
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}

export default App;
